/* JS4AI on GitHub */
This repository is a collection of John's scripts for Adobe Illustrator. 
All scripts created by John Wundes unless otherwise noted.
Full copyright text here:
http://www.wundes.com/js4ai/copyright.txt

The descriptions for each file can be found in the file's header text, but if you want to see all the descriptions on one page, take a look here.
http://www.wundes.com/js4ai

Subscribe to my blog for in-depth tutorials and new script alerts.
http://js4ai.blogspot.com/

Please feel free to branch custom versions for your needs, or email me if you want to add any of your scripts that you'd like to make public here.
Enjoy, and happy illustrating.
-J
 
/*
* Description: An Adobe Illustrator script that combine template layers and content layers
* Usage: Rename all "template" layers with an underscore "_" as the first character. Rename all "content" layers with any suitable names
* This is an early version that has not been sufficiently tested. Use at your own risks.
* License: GNU General Public License Version 3. (http://www.gnu.org/licenses/gpl-3.0-standalone.html)
*
* Copyright (c) 2009. William Ngan.
* http://www.metaphorical.net

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


var doc = app.activeDocument;
var origlayers = new Array();


// Record all original content layers
for(var i=0; i<doc.layers.length; i++) {
	
	if ( !(doc.layers[i].name.charAt(0)=='_') ) {
		origlayers.push( doc.layers[i].name );
	}
}

// Generate comp layers
for(var i=0; i<origlayers.length; i++) {
	getContent( origlayers[i] );
}


// Distinguish non-comp layers and comp layers by visibility
origlayers = new Array();
for(var i=0; i<doc.layers.length; i++) {
	
	// non-comp
	if (doc.layers[i].name.substr(0,5)!='comp_') {
		doc.layers[i].visible = true;
		origlayers.push( doc.layers[i].name );

	// comp
	} else {
		doc.layers[i].visible = false;
	}
}


// Remove non-comp layers
for(var i=0; i<origlayers.length; i++) {
	doc.layers.getByName (origlayers[i]).remove();
}

// show first comp layer
doc.layers[0].visible = true;

/**
* opens a resource file and copy the specific layer to page
* @param layername the name of the layer
*/
function getContent(layername) {
	
	// open resource file
	var tempdoc = null;
	
	try {

	} catch (err) {
		throw new Error( 'Cannot create new document' );
	}

	// create a new layer
	var temp_layer = doc.layers.add();
	temp_layer.name = 'comp_'+layername;
	temp_layer.visible = true;
	var gg = temp_layer.groupItems.add();

	// get specified layer. all unrelated layers set to invisible
	for(var i=doc.layers.length-1; i>=0; i--) {
		
		if (doc.layers[i].name.charAt(0)=='_') { // persistent layers with "_"
			doc.layers[i].visible = true;	
			group( gg, doc.layers[i].pageItems, true );
			
		} else if (doc.layers[i].name.substr(0,5)!='comp_') { // not comp layer
			doc.layers[i].visible = false;	
		}
	}

	try {
		var content = doc.layers.getByName(layername);
	} catch (err) {
		throw new Error('Cannot get contents from '+layername+'* layer');
	}

	// group content
	content.visible = true;
	group( gg, content.pageItems, true );

}


function group( gg, items, isDuplicate ) {

	for(var i=items.length-1; i>=0; i--) {

		if (items[i]!=gg) { 
			if (isDuplicate) {
				newItem = items[i].duplicate (gg, ElementPlacement.PLACEATBEGINNING);
			} else {
				items[i].move( gg, ElementPlacement.PLACEATBEGINNING );
			}
		}
	}

}

